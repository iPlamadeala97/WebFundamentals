//First Like Button
var count1 = 9
var count1Element = document.querySelector("#Like1");

function add1() {
    count1++;
    count1Element.innerText = count1 + " like(s)";
}

//Second Like Button
var count2 = 12
var count2Element = document.querySelector("#Like2");

function addOne() {
    count2++;
    count2Element.innerText = count2 + " like(s)";
}

//First Like Button
var count3 = 9
var count3Element = document.querySelector("#Like3");

function addUno() {
    count3++;
    count3Element.innerText = count3 + " like(s)";
}
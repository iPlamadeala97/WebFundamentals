function play(element) {
    element.play(play);
}

function pause(element) {
    element.pause(pause);
}

